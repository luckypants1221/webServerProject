
  # 웹서버 프로젝트

  This is a code bundle for 웹서버 프로젝트. The original project is available at https://www.figma.com/design/YdbvOk4yQGMsQFHUvwXIjl/%EC%9B%B9%EC%84%9C%EB%B2%84-%ED%94%84%EB%A1%9C%EC%A0%9D%ED%8A%B8.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  